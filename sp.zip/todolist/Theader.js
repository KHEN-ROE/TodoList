import React from 'react'


const Theader = () => {
  return (
    <div className='thead'>
      <h1>What's your OneThing of today?</h1>
    </div>
  )
}

export default Theader
